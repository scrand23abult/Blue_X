#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <cstdlib>
#include <ctime>



int main() {
	
	
    // Crear la ventana del juego
    sf::RenderWindow window(sf::VideoMode(1300, 700), "Pong");

    // Cargar la imagen de fondo
    sf::Texture backgroundTexture;
    if (!backgroundTexture.loadFromFile("C:\\global\\imagenes\\panataaasasasdddddd.jfif")) {
        return -1; // Error al cargar la imagen
    }
    sf::Sprite background(backgroundTexture);

    // Cargar el archivo de sonido
    sf::SoundBuffer buffer;
    if (!buffer.loadFromFile("C:\\global\\sonidos\\bubblebeam-41985.wav")) {
        return -1; // Error al cargar el archivo de sonido
    }

    sf::Sound collisionSound;
    collisionSound.setBuffer(buffer);
    
    // Crear las bolas (antes paletas) y la pelota
    sf::CircleShape oval1(30); // Radio de 30 para agrandar las bolas
    sf::CircleShape oval2(30);
    sf::CircleShape ball(20); // Radio de 20 para la pelota

    // Posicionar las bolas y la pelota
    oval1.setPosition(50, 325); // Centrar verticalmente en la pantalla
    oval2.setPosition(1225, 325); // Ajustar posici�n para que est� en el borde derecho y centrado verticalmente
    ball.setPosition(645, 345); // Centrar la pelota en la pantalla

    // Velocidades de los objetos
    sf::Vector2f oval1Velocity(1.0f, 1.0f); // Velocidad para oval1
    sf::Vector2f oval2Velocity(1.0f, 1.0f); // Velocidad para oval2
    sf::Vector2f ballVelocity(0.7f, 0.7f);  // Velocidad para la pelota

    // Crear y posicionar los rect�ngulos l�mites y porter�as
    sf::RectangleShape topLimit(sf::Vector2f(1300, 10)); // L�mite superior
    sf::RectangleShape bottomLimit(sf::Vector2f(1300, 10)); // L�mite inferior
    sf::RectangleShape leftLimitTop(sf::Vector2f(10, 250)); // L�mite izquierdo superior
    sf::RectangleShape leftLimitBottom(sf::Vector2f(10, 250)); // L�mite izquierdo inferior
    sf::RectangleShape rightLimitTop(sf::Vector2f(10, 250)); // L�mite derecho superior
    sf::RectangleShape rightLimitBottom(sf::Vector2f(10, 250)); // L�mite derecho inferior

    topLimit.setPosition(0, 0);
    bottomLimit.setPosition(0, 690); // 700-10
    leftLimitTop.setPosition(0, 0);
    leftLimitBottom.setPosition(0, 450); // Deja un espacio de 200 p�xeles en el centro
    rightLimitTop.setPosition(1290, 0); // 1300-10
    rightLimitBottom.setPosition(1290, 450); // Deja un espacio de 200 p�xeles en el centro

    topLimit.setFillColor(sf::Color::Red);
    bottomLimit.setFillColor(sf::Color::Red);
    leftLimitTop.setFillColor(sf::Color::Red);
    leftLimitBottom.setFillColor(sf::Color::Red);
    rightLimitTop.setFillColor(sf::Color::Red);
    rightLimitBottom.setFillColor(sf::Color::Red);

    // Contador de colisiones
    int collisionCount = 0;

    // Bucle principal del juego
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        // Movimiento de las bolas
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) && oval1.getPosition().y > 0)
            oval1.move(0, -oval1Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) && oval1.getPosition().y < 650) // Ajustar l�mite inferior
            oval1.move(0, oval1Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) && oval1.getPosition().x > 0)
            oval1.move(-oval1Velocity.x, 0);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) && oval1.getPosition().x < 1270) // Ajustar l�mite derecho
            oval1.move(oval1Velocity.x, 0);

        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && oval2.getPosition().y > 0)
            oval2.move(0, -oval2Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && oval2.getPosition().y < 650) // Ajustar l�mite inferior
            oval2.move(0, oval2Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && oval2.getPosition().x > 0)
            oval2.move(-oval2Velocity.x, 0);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && oval2.getPosition().x < 1270) // Ajustar l�mite derecho
            oval2.move(oval2Velocity.x, 0);

        // Movimiento de la pelota
        ball.move(ballVelocity);

        // Colisiones con los l�mites superior e inferior
        if (ball.getPosition().y <= 0 || ball.getPosition().y >= 690) {
            ballVelocity.y = -ballVelocity.y;
            collisionSound.play();
        }

        // Colisiones con los l�mites laterales (excepto las porter�as)
        if ((ball.getPosition().x <= 0 && (ball.getPosition().y < 250 || ball.getPosition().y > 450)) ||
            (ball.getPosition().x >= 1285 && (ball.getPosition().y < 250 || ball.getPosition().y > 450))) {
            ballVelocity.x = -ballVelocity.x;
            collisionSound.play();
        }

        // Si la pelota sale por una porter�a, reaparecer en el centro
        if (ball.getPosition().x <= -30 || ball.getPosition().x >= 1330) { // Considerar el radio de la pelota
            ball.setPosition(645, 345); // Centrar la pelota en la pantalla
        }

        // Colisiones con las bolas
        if (ball.getGlobalBounds().intersects(oval1.getGlobalBounds()) || ball.getGlobalBounds().intersects(oval2.getGlobalBounds())) {
            ballVelocity.x = -ballVelocity.x;
            collisionSound.play();
            
            // Aumentar el contador de colisiones
            collisionCount++;
            
            // Incrementar la velocidad cada 15 colisiones
            if (collisionCount % 15 == 0) {
            	if( ballVelocity.x < 2.5 ){
            		ballVelocity.x *= 1.05f; // Incremento m�s gradual
                	ballVelocity.y *= 1.05f; // Incremento m�s gradual	
				}
                
            }
        }

        oval1.setFillColor(sf::Color(0, 0, 139)); // Azul intenso (RGB: 0, 0, 139)
        oval2.setFillColor(sf::Color(0, 255, 0)); // Verde (RGB: 0, 255, 0)
        ball.setFillColor(sf::Color(135, 0, 0)); // Rojo oscuro (RGB: 135, 0, 0)

        // Dibujar los objetos en la ventana
        window.clear();
        window.draw(background); // Dibujar la imagen de fondo
        window.draw(topLimit);
        window.draw(bottomLimit);
        window.draw(leftLimitTop);
        window.draw(leftLimitBottom);
        window.draw(rightLimitTop);
        window.draw(rightLimitBottom);
        window.draw(oval1);
        window.draw(oval2);
        window.draw(ball);
        window.display();
    }

    return 0;
}


