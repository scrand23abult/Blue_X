#include <SFML/Graphics.hpp>
#include <SFML/Window.hpp>
#include <SFML/Audio.hpp>
#include <cstdlib>
#include <ctime>
#include <string.h>
#include <iostream>

using namespace std;

int main() {
	sf::SoundBuffer buffer;
    if (!buffer.loadFromFile("C:\\global\\sonidos\\bubbles-003-6397.wav")) {
        std::cerr << "Error al cargar el audio" << std::endl;
        return -1;
    } 
	 sf::Sound sound(buffer);
    	sound.setLoop(true);
    	sound.play();
    sf::RenderWindow window(sf::VideoMode(1300, 700), "Bubble Soccer");

    // Pantalla inicial
    bool inMainMenu = true;

    // Texto para la pantalla inicial
    sf::Font font;
    if (!font.loadFromFile("C:\\global\\fuentes\\arial.ttf")) {
        return -1; // Error al cargar la fuente
    }

    // Obtener las dimensiones de la ventana
    sf::Vector2u windowSize = window.getSize();
    
    // Cargar la imagen de fondo para el men�
    sf::Texture menuBackgroundTexture;
    if (!menuBackgroundTexture.loadFromFile("C:\\global\\frams\\Pantalla de Inicio.png")) {
        return -1; // Error al cargar la imagen del men�
    } 
	sf::Sprite sprite;
    sf::Sprite menuBackground(menuBackgroundTexture);

    // Cargar y declarar las imagens de fondo para el juego
    
    sf::Texture newTexture1;
    if (!newTexture1.loadFromFile("C:\\global\\frams\\pLAYA_0001.png")) {
        return -1; // Error al cargar la imagen del juego
    }
    sf::Sprite gameBackground(newTexture1);
    
 
    // Cargar el archivo de sonido
   
    if (!buffer.loadFromFile("C:\\global\\sonidos\\bubble-pop-283674.wav")) {
        return -1; // Error al cargar el archivo de sonido
    }

    sf::Sound collisionSound;
    collisionSound.setBuffer(buffer);

    // Definir las texturas para las bolas
    sf::Texture oval1Texture;
    sf::Texture oval2Texture;

    // Cargar las texturas desde los archivos
    if (!oval1Texture.loadFromFile("C:\\global\\imagenes\\Caballito A.png")) {
        return -1; // Error al cargar la textura de oval1
    }
    if (!oval2Texture.loadFromFile("C:\\global\\imagenes\\Caballito B.png")) {
        return -1; // Error al cargar la textura de oval2
    }

    // Crear las bolas (antes paletas) y la pelota
    sf::CircleShape oval1(40); // Radio para agrandar las bolas
    sf::CircleShape oval2(40);

    // Asignar las texturas a los objetos ovalados
    oval1.setTexture(&oval1Texture);
    oval2.setTexture(&oval2Texture);

    // Cargar la textura de la imagen para la pelota
    sf::Texture ballTexture;
    if (!ballTexture.loadFromFile("C:\\global\\imagenes\\pixilborbuja-frame-0 (1).png")) {
        return -1; // Error al cargar la imagen
    }

    // Crear un sprite para la pelota y asignarle la textura cargada
    sf::Sprite ball;
    ball.setTexture(ballTexture);
    ball.setScale(0.06f, 0.06f); // Ajusta el tama�o de la imagen si es necesario

    // Posicionar las bolas y la pelota
    oval1.setPosition(50, 325); // Centrar verticalmente en la pantalla
    oval2.setPosition(1225, 325); // Ajustar posici�n para que est� en el borde derecho y centrado verticalmente
    ball.setPosition(645, 345); // Centrar la pelota en la pantalla

    // Velocidades de los objetos
    sf::Vector2f oval1Velocity(1.0f, 1.0f); // Velocidad para oval1
    sf::Vector2f oval2Velocity(1.0f, 1.0f); // Velocidad para oval2
    sf::Vector2f ballVelocity(0.7f, 0.7f);  // Velocidad para la pelota

    // Crear y posicionar los rect�ngulos l�mites y porter�as
    sf::RectangleShape topLimit(sf::Vector2f(1300, 10)); // L�mite superior
    sf::RectangleShape bottomLimit(sf::Vector2f(1300, 10)); // L�mite inferior
    sf::RectangleShape leftLimitTop(sf::Vector2f(10, 250)); // L�mite izquierdo superior
    sf::RectangleShape leftLimitBottom(sf::Vector2f(10, 250)); // L�mite izquierdo inferior
    sf::RectangleShape rightLimitTop(sf::Vector2f(10, 250)); // L�mite derecho superior
    sf::RectangleShape rightLimitBottom(sf::Vector2f(10, 250)); // L�mite derecho inferior

    topLimit.setPosition(0, 0);
    bottomLimit.setPosition(0, 690); // 700-10
    leftLimitTop.setPosition(0, 0);
    leftLimitBottom.setPosition(0, 450); // Deja un espacio de 200 p�xeles en el centro
    rightLimitTop.setPosition(1290, 0); // 1300-10
    rightLimitBottom.setPosition(1290, 450); // Deja un espacio de 200 p�xeles en el centro

    topLimit.setFillColor(sf::Color::Red);
    bottomLimit.setFillColor(sf::Color::Red);
    leftLimitTop.setFillColor(sf::Color::Red);
    leftLimitBottom.setFillColor(sf::Color::Red);
    rightLimitTop.setFillColor(sf::Color::Red);
    rightLimitBottom.setFillColor(sf::Color::Red);

    // Contador de colisiones
    int collisionCount = 0;

    // Bucle principal del juego
    while (window.isOpen()) {
        sf::Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed)
                window.close();
            if (event.type == sf::Event::MouseButtonPressed) {
                if (event.mouseButton.button == sf::Mouse::Left) {
                    inMainMenu = false;
                }
            }
        }
        // Pantalla inicial
        if (inMainMenu) {
            window.clear();
            window.draw(menuBackground); // Dibujar el fondo del men�
            
            window.display();
            continue;
        }
        // Movimiento de las bolas
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::W) && oval1.getPosition().y > 0)
            oval1.move(0, -oval1Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::S) && oval1.getPosition().y < 650) // Ajustar l�mite inferior
            oval1.move(0, oval1Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::A) && oval1.getPosition().x > 0)
            oval1.move(-oval1Velocity.x, 0);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::D) && oval1.getPosition().x < 1270) // Ajustar l�mite derecho
            oval1.move(oval1Velocity.x, 0);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Up) && oval2.getPosition().y > 0)
            oval2.move(0, -oval2Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Down) && oval2.getPosition().y < 650) // Ajustar l�mite inferior
            oval2.move(0, oval2Velocity.y);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Left) && oval2.getPosition().x > 0)
            oval2.move(-oval2Velocity.x, 0);
        if (sf::Keyboard::isKeyPressed(sf::Keyboard::Right) && oval2.getPosition().x < 1270) // Ajustar l�mite derecho
            oval2.move(oval2Velocity.x, 0);

        // Movimiento de la pelota
        ball.move(ballVelocity);

        // Colisiones con los l�mites superior e inferior
        if (ball.getPosition().y <= 0 || ball.getPosition().y >= 690) {
            ballVelocity.y = -ballVelocity.y;
            collisionSound.play();
        }

        // Colisiones con los l�mites laterales (excepto las porter�as)
        if ((ball.getPosition().x <= 10 && (ball.getPosition().y < 250 || ball.getPosition().y > 450)) ||
            (ball.getPosition().x >= 1285 && (ball.getPosition().y < 250 || ball.getPosition().y > 450))) {
            ballVelocity.x = -ballVelocity.x;
            collisionSound.play();
        }
        // Si la pelota sale por una porter�a, reaparecer en el centro
        if (ball.getPosition().x <= -30 || ball.getPosition().x >= 1330) { // Considerar el radio de la pelota
            	ball.setPosition(645, 345); // Centrar la pelota en la pantalla 			
        }
        // Colisiones con las bolas
        if (ball.getGlobalBounds().intersects(oval1.getGlobalBounds()) || ball.getGlobalBounds().intersects(oval2.getGlobalBounds())) {
            ballVelocity.x = -ballVelocity.x;
            collisionSound.play();
            
            // Aumentar el contador de colisiones
            collisionCount++;
            
            // Incrementar la velocidad cada 15 colisiones
            if (collisionCount % 25 == 0) {
                if(ballVelocity.x < 1.07) {
                    ballVelocity.x *= 1.005f; // Incremento m�s gradual de la velocidad de ball en el eje x
                    ballVelocity.y *= 1.005f; // Incremento m�s gradual de la velocidad de ball en el eje y 
                }
            }
        }
    
        // Dibujar los objetos en la ventana
        window.clear();
        window.draw(gameBackground);
        window.draw(topLimit);
        window.draw(bottomLimit);
        window.draw(leftLimitTop);
        window.draw(leftLimitBottom);
        window.draw(rightLimitTop);
        window.draw(rightLimitBottom);
        window.draw(oval1);
        window.draw(oval2);
        window.draw(ball);
        window.display();
    }
    return 0;
}
